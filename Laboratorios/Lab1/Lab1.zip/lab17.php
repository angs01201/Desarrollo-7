<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF - 8">
	</head>
	<body>
		<?php
		$x = 24;
		$pi = 3.1416;
		$animal = "conejo";
		$saludo = "hola caracola";
		echo $x , " <br> " , $pi , " <br> " , $animal , " <br> " , $saludo;
		?>
	</body>
</html>